<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitor Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: lightskyblue;
            color: black;
            padding: 10px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .logo {
            max-height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .sidebar {
            width: 200px;
            background-color: grey;
            color: white;
            padding: 20px;
            position: fixed;
            height: calc(100% - 60px);
            top: 40px;
            overflow: hidden;
        }
        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .sidebar a:hover {
            background-color: LightGray;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
            padding-top: 80px;
        }
        footer {
            background-color: lightskyblue;
            color: black;
            text-align: right;
            padding: 10px;
            position: relative;
            bottom: 0;
            height: 20px;
        }
        .logout-button {
            background-color: black;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 40px;
        }
        .logout-button:hover {
            background-color: black;
        }
    </style>
    <script>
        function logout() {
            alert("You have been logged out.");
            window.location.href = 'login.html';
        }
    </script>
</head>
<body>

<header>
    <img src="image.png" alt="Logo" class="logo">
    <h1 style="margin: 0;">Visitor Management System</h1>
    <button class="logout-button" onclick="logout()">Logout</button>
</header>

<div class="sidebar">
    <?php include 'side-bar.php'; ?>
</div>

<div class="content">
    <!-- Content will be included here based on the sidebar selection -->
</div>

<footer>
    <p style="margin: 0;">Bluebase Software Services Private Limited</p>
</footer>

</body>
</html>
