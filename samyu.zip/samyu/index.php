<?php
session_start();
include 'connection.php';
if(isset($_REQUEST['login_btn']))
{
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    
    $select_query = mysqli_query($conn,"SELECT id, user_name FROM tbl_users WHERE emailid='$email' AND password='$pwd'");
    $rows = mysqli_num_rows($select_query);
    if($rows > 0)
    {
        $username = mysqli_fetch_row($select_query);
        
        $_SESSION['id'] = $username[0];
        $_SESSION['name'] = $username[1];
        header("Location: layout.php"); 
    }
    else
    { ?>
        <script>
            alert("You have entered wrong email or password.");
        </script>
    <?php }
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Visitors Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa; /* Light background */
        }
        .container {
            max-width: 600px; /* Limit width of the form */
            margin-top: 100px; /* Center vertically */
        }
        .card {
            border: 1px solid #007bff; /* Blue border */
            border-radius: 10px; /* Rounded corners */
        }
        .card-header {
            background-color: #007bff; /* Blue background */
            color: white; /* White text */
            text-align: center; /* Center text */
            border-top-left-radius: 10px; /* Rounded corners */
            border-top-right-radius: 10px; /* Rounded corners */
        }
        .form-control {
            border-radius: 5px; /* Rounded corners */
        }
        .btn-primary {
            background-color: #007bff; /* Primary button color */
            border: none; /* No border */
        }
        .btn-primary:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card card-login mx-auto mt-5">
            <div class="card-header">
                <h2>Visitors Management System (VMS)</h2>
            </div>
            <div class="card-body">
                <form name="login" method="post" action="">
                    <div class="form-group">
                        <div class="form-label-group">
                        <label for="inputEmail">Email address</label>
                            <input type="email" id="inputEmail" class="form-control" name="email" placeholder="Email address" required autofocus>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label-group">
                        <label for="inputPassword">Password</label>
                            <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="pwd" required>
                            
                        </div>
                    </div>
                    <input type="submit" class="btn btn-primary btn-block" name="login_btn" value="Login">
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
