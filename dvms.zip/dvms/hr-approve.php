<?php
session_start();
include('connection.php');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if (empty($id)) {
    header("Location: hr-manage-visitor.php");
    exit;
}

// Determine what to do based on the action
if ($action === 'approve') {
    // Update visitor status to "Approved"
    $update_query = mysqli_query($conn, "UPDATE tbl_visitors SET status='Approved' WHERE id='$id'");
    if ($update_query) {
        header("Location: hr-manage-visitor.php?msg=");
    } 
} elseif ($action === 'reject') {
    // Update visitor status to "Rejected"
    $update_query = mysqli_query($conn, "UPDATE tbl_visitors SET status='Rejected' WHERE id='$id'");
    if ($update_query) {
        header("Location: hr-manage-visitor.php?msg");
    } 
}

// Fetch visitor details from the database
$query = mysqli_query($conn, "SELECT * FROM tbl_visitors WHERE id='$id'");

if (mysqli_num_rows($query) == 0) {
    echo "<p>No visitor found.</p>";
    exit;
}

$visitor = mysqli_fetch_assoc($query);
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="hr-manage-visitor.php">Manage Visitors</a>
                </li>
                <li class="breadcrumb-item active">View Visitor</li>
            </ol>

            <!-- Visitor Details -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    Visitor Details
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <tr>
                                <th>Name</th>
                                <td><?php echo htmlspecialchars($visitor['name']); ?></td>
                            </tr>
                            <tr>
                                <th>Organization</th>
                                <td><?php echo htmlspecialchars($visitor['organization']); ?></td>
                            </tr>
                            <tr>
                                <th>Contact Number</th>
                                <td><?php echo htmlspecialchars($visitor['cno']); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo htmlspecialchars($visitor['email']); ?></td>
                            </tr>
                            <tr>
                                <th>Location</th>
                                <td><?php echo htmlspecialchars($visitor['location']); ?></td>
                            </tr>
                            <tr>
                                <th>No. Of Vehicle</th>
                                <td><?php echo htmlspecialchars($visitor['No_of_vec']); ?></td>
                            </tr>
                            <tr>
                                <th>Vehicle Type</th>
                                <td><?php echo htmlspecialchars($visitor['vectype']); ?></td>
                            </tr>
                            <tr>
                                <th>Vehicle Registration No</th>
                                <td><?php echo htmlspecialchars($visitor['vecregno']); ?></td>
                            </tr>
                            <tr>
                                <th>No. Of Laptop</th>
                                <td><?php echo htmlspecialchars($visitor['no_of_laptop']); ?></td>
                            </tr>
                            <tr>
                                <th>Laptop Serial Number</th>
                                <td><?php echo htmlspecialchars($visitor['lapsrno']); ?></td>
                            </tr>
                            <tr>
                                <th>Laptop Model</th>
                                <td><?php echo htmlspecialchars($visitor['lapmodel']); ?></td>
                            </tr>
                            <tr>
                                <th>No. Of Charger</th>
                                <td><?php echo htmlspecialchars($visitor['no_of_charger']); ?></td>
                            </tr>
                            <tr>
                                <th>Purpose of Visit</th>
                                <td><?php echo htmlspecialchars($visitor['visit']); ?></td>
                            </tr>
                            <tr>
                                <th>Person to Meet</th>
                                <td><?php echo htmlspecialchars($visitor['meet']); ?></td>
                            </tr>
                            <tr>
                                <th>In Time</th>
                                <td><?php echo htmlspecialchars($visitor['in_time']); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="form-group">
                        <a href="hr-manage-visitor.php" class="btn btn-secondary">Back to List</a>
                        <a href="hr-approve.php?action=approve&id=<?php echo $visitor['id']; ?>" class="btn btn-success">Approve</a>
                        <a href="hr-approve.php?action=reject&id=<?php echo $visitor['id']; ?>" class="btn btn-danger">Reject</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>
