<?php
session_start();
include('connection.php');

$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
}

if (isset($_POST['sbt-vstr'])) {
    $No_of_person = $_POST['No_of_person'];
    $name = $_POST['name'];
    $cno = $_POST['cno'];
    $email = $_POST['email'];
    $organization = $_POST['organization'];
    $location = $_POST['location'];
    $No_of_vec = $_POST['No_of_vec'];
    $vectype = $_POST['vectype'];
    $vecregno = $_POST['vecregno'];
    $no_of_phones = $_POST['no_of_phones'];
    $mobtype = $_POST['mobtype'];
    $no_of_laptop = $_POST['no_of_laptop'];
    $lapsrno = $_POST['lapsrno'];
    $lapmodel = $_POST['lapmodel'];
    $no_of_charger = $_POST['no_of_charger'];   
    $meet = $_POST['meet'];
    $visit = $_POST['visit'];
    $visitor_name = $_POST['visitor_name'];
    $in_time = $_POST['in_time'];
    // print_r($no_of_phones);

    for ($i = 0; $i < $No_of_person; $i++) {
        // $name = $name[$i];
        // $cno = $cno[$i];
        // $email = $email[$i];
        // $vectype = $vectype[$i];
        // $vecregno = $vecregno[$i];
        // $lapsrno = $lapsrno[$i];
        // $lapmodel = $lapmodel[$i];

    // Insert visitor data into database
    $insert_visitor = mysqli_query($conn,"INSERT into tbl_visitors (No_of_person, name, cno, 
    email, organization,location, No_of_vec, vectype, vecregno, no_of_phones, no_of_laptop, 
    lapsrno, lapmodel, no_of_charger, meet, visit,visitor_name, in_time)  VALUES ('$No_of_person', '$name[$i]', 
    '$cno[$i]', '$email[$i]', '$organization', '$location','$No_of_vec', '$vectype[$i]', '$vecregno[$i]', 
    '$no_of_phones', '$no_of_laptop', '$lapsrno[$i]', '$lapmodel[$i]', '$no_of_charger','$meet',
    '$visit','$visitor_name', '$in_time')");

}
if ($insert_visitor) {
    echo "<script>alert('Visitor added successfully.');</script>";
} else {
    echo "<script>alert('Error occurred while adding visitor.');</script>";
}
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Visitors</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    Submit Details
                </div>
                <div class="card-body">
                    <form method="post" class="form-valide">
                        <div class="row">

  <!----------------------------------------Person----------------------------------------->
                           <!-- No. of Person -->
                           <div class="col-md-3 pt-3">
                                <label>No. Of Person</label>
                                <input type="text" class="form-control" style="height: 35px;" name="No_of_person" id="No_of_person" oninput="createPersonFields()" required>
                            </div>

                            <!-- Additional Dynamic Fields -->
                            <div id="persons"></div>

                            <script>
                            function createPersonFields() {
                                var noOfPersons = parseInt(document.getElementById("No_of_person").value);
                                var personsDiv = document.getElementById("persons");

                                // Clear previous entries
                                personsDiv.innerHTML = '';

                                for (var i = 0; i < noOfPersons; i++) {
                                    var div = document.createElement('div');
                                    div.className = 'row mb-2';

                                    div.innerHTML = `
                                        <div class="col-md-4">
                                            <label>Full Name</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="name[]" required>
                                        </div>          
                                        <div class="col-md-4">
                                            <label>Contact Number</label>
                                            <input type="text" maxlength="10" class="form-control" style="height: 35px;width:280px" name="cno[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Email</label>
                                            <input type="email" class="form-control" style="height: 35px;width:280px" name="email[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>No. Of Vehicle</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="No_of_vec" id="No_of_vec${i}" onchange="toggleVehicleFields(${i})">
                                                <option value="">Select</option>
                                                <option value="yes">Yes</option>
                                                <option value="no">No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 vehicle-fields_${i}" style="display: none;">
                                            <label>Vehicle Type</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="vectype[]" required>
                                        </div>
                                        <div class="col-md-4 vehicle-fields_${i}" style="display: none;">
                                            <label>Registration No</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="vecregno[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>No. Of Laptop</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="no_of_laptop" id="No_of_laptop${i}" onchange="toggleLaptopFields(${i})">
                                                <option value="">Select</option>
                                                <option value="yes">Yes</option>
                                                <option value="no">No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 laptop-fields_${i}" style="display: none;">
                                            <label>Serial Number</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="lapsrno[]" required>
                                        </div>
                                        <div class="col-md-4 laptop-fields_${i}" style="display: none;">
                                            <label>Laptop Model</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="lapmodel[]" required>
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <label>No of Phones</label>
                                            <input type="number" class="form-control" style="height: 35px;width:280px" name="no_of_phones" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Mobile Type</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="mobtype[]" required>
                                                <option value="">Select</option>
                                                <option value="With Camera">With Camera</option>
                                                <option value="Without Camera">Without Camera</option>
                                            </select>
                                        </div>
                                    `;

                                    personsDiv.appendChild(div);
                                }

                                // Disable the No_of_person input to prevent further changes
                                document.getElementById("No_of_person").setAttribute("readonly", "readonly");
                            }

                            function toggleVehicleFields(index) {
                                var vehicleFields = document.querySelectorAll(`.vehicle-fields_${index}`);
                                var vehicleSelect = document.getElementById(`No_of_vec${index}`);
                                
                                if (vehicleSelect.value === 'yes') {
                                    vehicleFields.forEach(field => field.style.display = 'block');
                                } else {
                                    vehicleFields.forEach(field => field.style.display = 'none');
                                }
                            }

                            function toggleLaptopFields(index) {
                                var laptopFields = document.querySelectorAll(`.laptop-fields_${index}`);
                                var laptopSelect = document.getElementById(`No_of_laptop${index}`);
                                
                                if (laptopSelect.value === 'yes') {
                                    laptopFields.forEach(field => field.style.display = 'block');
                                } else {
                                    laptopFields.forEach(field => field.style.display = 'none');
                                }
                            }

                            function toggleMobileFields(index) {
                                var mobileFields = document.querySelectorAll(`.mobile-fields_${index}`);
                                var mobileSelect = document.getElementById(`No_of_mobile${index}`);
                                
                                if (mobileSelect.value === 'yes') {
                                    mobileFields.forEach(field => field.style.display = 'block');
                                } else {
                                    mobileFields.forEach(field => field.style.display = 'none');
                                }
                            }
                            </script>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Organization</label>
                                    <input type="text" name="organization" style="height: 35px;" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Location</label>
                                    <input type="text" style="height: 35px;" name="location" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>No.Of.Charger</label>
                                    <input type="number" class="form-control" style="height: 35px;" name="no_of_charger" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Purpose of Visit</label>
                                    <input type="text" style="height: 35px;" name="visit" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                <label class="form-label" for="meet">Person to Meet<span class="text-danger"></span></label>
                                <!-- <input type="text" name="meet" style="height: 35px;" class="form-control" required> -->
                                <select class="form-control" id="meet" name="meet" required>
                                    <option value=""> </option>
                                    <option value="HR">HR</option>
                                    <option value="IT">IT</option>
                                    <option value="HOD">HOD</option>
                                    <option value="Time Office">Time Office</option>
                                    <option value="General staff">General staff</option>
                                </select>    
                            </div>
                            </div>
                            
                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Visitor Name</label>
                                    <select name="visitor_name" class="form-control" style="height: 35px;" required>
                                        <?php
                                        // Include the database connection file
                                        include('connection.php');

                                        // Query to fetch names from the database
                                        $query = "SELECT fname FROM tbl_department"; // Replace 'visitors' with your actual table name
                                        $result = mysqli_query($conn, $query);

                                        // Check if the query was successful
                                        if ($result) {
                                            // Loop through the results and create an option for each name
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo '<option value="' . htmlspecialchars($row['fname']) . '">' . htmlspecialchars($row['fname']) . '</option>';
                                            }
                                        } else {
                                            // Handle errors, e.g., log them or display a message
                                            echo '<option value="">No names available</option>';
                                        }

                                        // Close the database connection
                                        mysqli_close($conn);
                                        ?>
                                    </select>
                                </div>
                            </div>


                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Visit Date and Time</label>
                                    <input type="datetime-local" style="height: 35px;" name="in_time" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-12 pt-3">
                                <button type="submit" name="sbt-vstr" class="btn btn-success">Submit</button>
                                <button type="button" class="btn btn-secondary" onclick="window.location.href='index.php'">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>

