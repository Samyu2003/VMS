<?php
session_start();
include('connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if(empty($id)) {
    header("Location: index.php"); 
}

// Fetch the message from query string
$hr_visitors_query = mysqli_query($conn, "SELECT * FROM tbl_visitors WHERE meet = 'IT'");
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
?>

<
<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">IT Department</a>
                </li> 
            </ol>

            <!-- Visitors Table -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    IT Visitor Details
                </div>
   
            <!-- Display message -->
            <?php if ($message): ?>
                <div class="alert alert-info">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

          

            <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Organization</th>
                                    <th>Mobile</th>
                                    <th>Department</th>
                                    <th>Person to meet</th>
                                    <th>In Time</th>
                                    <th>Status</th>
                                    <th>Status Update</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sn = 1;
                                while($row = mysqli_fetch_array($hr_visitors_query)) { ?>
                                    <tr>
                                        <td><?php echo $sn; ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['organization']); ?></td>
                                        <td><?php echo htmlspecialchars($row['cno']); ?></td>
                                        <td><?php echo htmlspecialchars($row['meet']); ?></td>
                                        <td><?php echo htmlspecialchars($row['visitor_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['in_time']); ?></td>
                                        <td><?php echo htmlspecialchars($row['status'] ? $row['status'] : 'Pending'); ?></td>
                                        <td>
                                            <a href="it-approve.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">View</a>
                                        </td>
                                    </tr>
                                    <?php 
                                    $sn++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>                   
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>
