<?php


if (isset($_POST['image'])) {
    $data = $_POST['image'];

    // Remove the base64 header from the image data
    $image_parts = explode(";base64,", $data);
    $image_base64 = base64_decode($image_parts[1]);
    $file_name = uniqid() . '.png';

    // Save the image to the uploads folder
    // file_put_contents('uploads/' . $file_name, $image_base64);

    echo "Image uploaded successfully. File saved as: " . $file_name;
} else {
    echo "No image data received.";
}
?>
