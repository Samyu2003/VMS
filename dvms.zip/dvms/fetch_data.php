<?php
include 'connection.php';

// Fetch data for the first chart (visitors per month)
$visitorsPerMonthQuery = mysqli_query($conn, "
    SELECT COUNT(id) AS visitors, MONTH(date) AS month 
    FROM tbl_visitors 
    GROUP BY month");

$visitorsPerMonth = [];
$months = [];
while ($row = mysqli_fetch_assoc($visitorsPerMonthQuery)) {
    $visitorsPerMonth[] = $row['visitors'];
    $months[] = $row['month'];
}

// Fetch data for the second chart (visitors per department)
$deptVisitorsQuery = mysqli_query($conn, "
    SELECT COUNT(tbl_visitors.id) AS visitors, des_table.department_name 
    FROM tbl_visitors 
    JOIN des_table ON tbl_visitors.dept_id = des_table.dept_id 
    GROUP BY des_table.department_name");

$visitorsPerDept = [];
$departments = [];
while ($row = mysqli_fetch_assoc($deptVisitorsQuery)) {
    $visitorsPerDept[] = $row['visitors'];
    $departments[] = $row['department_name'];
}

// Fetch data for the third chart (visitors per date, 1-30)
$visitorsPerDateQuery = mysqli_query($conn, "
    SELECT COUNT(id) AS visitors, DAY(date) AS day 
    FROM tbl_visitors 
    WHERE DAY(date) BETWEEN 1 AND 30 
    GROUP BY day");

$visitorsPerDate = [];
$dates = [];
while ($row = mysqli_fetch_assoc($visitorsPerDateQuery)) {
    $visitorsPerDate[] = $row['visitors'];
    $dates[] = $row['day'];
}

// Prepare data for JSON response
$response = [
    'months' => $months,
    'visitors_per_month' => $visitorsPerMonth,  
    'departments' => $departments,
    'visitors_per_dept' => $visitorsPerDept,
    'dates' => $dates,
    'visitors_per_date' => $visitorsPerDate,
    'visitors_per_month_2' => $visitorsPerMonth // Reuse the first data for the second month chart
];

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
