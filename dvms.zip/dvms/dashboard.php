<?php
session_start();
include 'connection.php'; // Ensure you have the database connection file
$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit;
}

?>
<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Dashboard</a>
                </li>
            </ol>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


            <!-- Four boxes with charts -->
            <div class="row">
                <!-- Box 1: Visitors per Month -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            Visitors per Month
                        </div>
                        <div class="card-body">
                            <canvas id="visitorsByMonthChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Box 2: Visitors per Department -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            Visitors per Department
                        </div>
                        <div class="card-body">
                            <select id="departmentFilter">
                                <!-- Populate departments dynamically from des_table -->
                                <?php
                                $result = mysqli_query($conn, "SELECT * FROM des_table");
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<option value='{$row['dept_id']}'>{$row['department_name']}</option>";
                                }
                                ?>
                            </select>
                            <canvas id="visitorsByDeptChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Box 3: Visitors per Date (1-30) -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            Visitors per Date (1-30)
                        </div>
                        <div class="card-body">
                            <canvas id="visitorsByDateChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Box 4: Visitors per Month -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            Visitors per Month
                        </div>
                        <div class="card-body">
                            <canvas id="visitorsByMonthSecondChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<?php include('include/footer.php'); ?>

<script>
// Data fetch via AJAX from PHP for the charts
// fetch('fetch_data.php')
//     .then(response => response.json())
//     .then(data => {
//         // First chart: Visitors per month
//         new Chart(document.getElementById('visitorsByMonthChart').getContext('2d'), {
//             type: 'bar',
//             data: {
//                 labels: data.months,  // Months (x-axis)
//                 datasets: [{
//                     label: 'Number of Visitors',
//                     data: data.visitors_per_month, // No. of visitors (y-axis)
//                     backgroundColor: 'rgba(75, 192, 192, 0.6)'
//                 }]
//             },
//             options: {
//                 scales: {
//                     x: { title: { display: true, text: 'Months' }},
//                     y: { title: { display: true, text: 'No. of Visitors' }}
//                 }
//             }
//         });

//         // Second chart: Visitors per department
//         new Chart(document.getElementById('visitorsByDeptChart').getContext('2d'), {
//             type: 'bar',
//             data: {
//                 labels: data.departments,  // Departments (x-axis)
//                 datasets: [{
//                     label: 'Number of Visitors',
//                     data: data.visitors_per_dept,  // No. of visitors (y-axis)
//                     backgroundColor: 'rgba(153, 102, 255, 0.6)'
//                 }]
//             },
//             options: {
//                 scales: {
//                     x: { title: { display: true, text: 'Department' }},
//                     y: { title: { display: true, text: 'No. of Visitors' }}
//                 }
//             }
//         });

//         // Third chart: Visitors per date (1-30)
//         new Chart(document.getElementById('visitorsByDateChart').getContext('2d'), {
//             type: 'bar',
//             data: {
//                 labels: data.dates,  // Dates (x-axis, 1-30)
//                 datasets: [{
//                     label: 'Number of Visitors',
//                     data: data.visitors_per_date,  // No. of visitors (y-axis)
//                     backgroundColor: 'rgba(255, 159, 64, 0.6)'
//                 }]
//             },
//             options: {
//                 scales: {
//                     x: { title: { display: true, text: 'Date' }},
//                     y: { title: { display: true, text: 'No. of Visitors' }}
//                 }
//             }
//         });

//         // Fourth chart: Second visitors per month chart
//         new Chart(document.getElementById('visitorsByMonthSecondChart').getContext('2d'), {
//             type: 'bar',
//             data: {
//                 labels: data.months,  // Months (x-axis)
//                 datasets: [{
//                     label: 'Number of Visitors',
//                     data: data.visitors_per_month_2,  // No. of visitors (y-axis)
//                     backgroundColor: 'rgba(54, 162, 235, 0.6)'
//                 }]
//             },
//             options: {
//                 scales: {
//                     x: { title: { display: true, text: 'Months' }},
//                     y: { title: { display: true, text: 'No. of Visitors' }}
//                 }
//             }
//         });
//     });
</script>
