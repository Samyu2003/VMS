<?php
session_start();
include('connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if (empty($id)) {
  header("Location: index.php");
}
if (isset($_REQUEST['sbt-dpt'])) {
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $deptname = $_POST['deptId'];
  // $deptname = $_POST['deptname'];
  $des = $_POST['des'];
  $mobile = $_POST['mobile'];
  $email = $_POST['email'];
  $hod = $_POST['hod'];
  $username = $_POST['username'];
  $pwd = $_POST['pwd'];
  $role = isset($_POST['role']) ? $_POST['role'] : '';
  $status = $_POST['status'];

  
  $insert_department = mysqli_query($conn, "INSERT INTO tbl_department (fname, lname, deptname, des, mobile, email, hod, username, pwd, role,status) 
  VALUES ('$fname', '$lname', '$deptname', '$des', '$mobile', '$email', '$hod', '$username', '$pwd', '$role', '$status')");
  // $insert_department = mysqli_query($conn, "insert into tbl_department set fname ='$fname',lname ='$lname', deptname='$deptname',
  // des='$des', mobile='$mobile', email='$email', hod='$hod', username='$username', pwd='$pwd', role='$role' ");

  if ($insert_department > 0) {
    ?>
    <script type="text/javascript">
      alert("Added successfully.")
    </script>
    <?php
  }
}
?>
<?php include('include/header.php'); ?>
<div id="wrapper">
  <?php include('include/side-bar.php'); ?>

  <div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <!-- <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Employee Details</a>
          </li>
        </ol> -->

      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-info-circle"></i>
          Employee Details
        </div>
        <form method="post" class="form-valide">
          <div class="card-body">
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="fname"> First Name <span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="fname" id="fname" class="form-control" placeholder="Enter First Name" required>
              </div>
            </div>
            <!-- <div class="card-body"> -->
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="lname">Last Name <span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="lname" maxlength="2" id="lname" class="form-control"
                  placeholder="Enter Last Name" required>
              </div>
            </div>

            <div class="form-group row">
                            <label class="col-lg-4 col-form-label" for="deptname">Department <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" id="deptname" name="deptId" required onchange="fetchDesignations(this.value)">
                                    <option value="">-- Select Department --</option>
                                    <?php
                                    $fetch_department = mysqli_query($conn, "SELECT * FROM add_det");
                                    while ($row = mysqli_fetch_array($fetch_department)) { ?>
                                        <option value="<?php echo htmlspecialchars($row['id']); ?>">
                                            <?php echo htmlspecialchars($row['deptname']); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label" for="des">Designation <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" id="des" name="des" required>
                                    <option value="">-- Select Designation --</option>
                                </select>
                            </div>
                        </div>
                       
            
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="mobile">Mobile Number <span
                  class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="mobile" maxlength="10" id="mobile" class="form-control"
                  placeholder="Enter mobile Number" required>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="email">Email <span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="email" id="email" class="form-control" placeholder="Enter email" required>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="hod">HOD<span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="radio" id="hod" name="hod" value="YES">
                <label for="hod">Yes</label>
                <input type="radio" id="hod" name="hod" value="NO">
                <label for="hod">No</label>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="username">User Name <span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="username" id="username" class="form-control" placeholder="Enter UserName"
                  required>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="pwd">Password<span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <input type="text" name="pwd" id="pwd" maxlength="8" class="form-control" placeholder="Enter Password"
                  required>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="role">Role<span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <select class="form-control" id="role" name="role" required>
                  <option value=""> -- Select Role --</option>
                  <option value="HR">HR</option>
                  <option value="IT">IT</option>
                  <option value="HOD">HOD</option>
                  <option value="Time Office">Time Office</option>
                  <option value="General staff">General staff</option>
                </select>
              </div>
            </div>

            <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="status">Status<span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <select class="form-control" id="status" name="status" required>
                  <option value=""> -- Select Role --</option>
                  <option value="IN">IN</option>
                  <option value="OUT">OUT</option>
                </select>
              </div>
            </div>

            <!-- <div class="form-group row">
              <label class="col-lg-4 col-form-label" for="status">Status<span class="text-danger">*</span></label>
              <div class="col-lg-6">
                <select name="status" id="status" class="form-control" required>
                  <option value="" disabled selected> -- Select Status --</option>
                  <option value="In">In</option>
                  <option value="Out">Out</option>
                </select>
              </div>
            </div> -->

            <!-- <div class="form-group row">
      <label class="col-lg-4 col-form-label" for="role">  Role<span class="text-danger"></span></label>
      <div class="col-lg-6">
      <select class="form-control" id="role" name="role" >
      <option value="">Select Role</option>
      <option value="">HR</option>
      <option value="">IT</option>
      <option value="">HOD</option>
      <option value="">Time Office</option>
      <option value="">General staff</option>
      </select>
      </div>    
      </div>                                                  -->
            <div class="form-group row">
              <div class="col-lg-8 ml-auto">
                <button type="submit" name="sbt-dpt" class="btn btn-primary">Submit</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php include('include/footer.php'); ?>


  <script>
        function fetchDesignations(departmentId) {
            if (departmentId) {
                const xhr = new XMLHttpRequest();
                xhr.open('GET', 'fetch_designations.php?dept_id=' + departmentId, true);
                xhr.onload = function () {
                    if (this.status == 200) {
                        const designations = JSON.parse(this.responseText);
                        let options = '<option value="">-- Select Designation --</option>';
                        designations.forEach(function (des) {
                            options += `<option value="${des.id}">${des.des}</option>`;
                        });
                        document.getElementById('des').innerHTML = options;
                    }
                };
                xhr.send();
            } else {
                document.getElementById('des').innerHTML = '<option value="">-- Select Designation --</option>';
            }
        }
    </script>
</div>