<?php
session_start();
include('connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
}
?>
<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">

            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fa fa-info-circle"></i>
                        Designation Details
                    </div>
                    <div class="d-flex align-items-center">
                        <form method="post" class="d-flex me-2">
                            <select class="form-control me-2" id="deptname" name="deptname">
                                <option value=""> -- Select Department -- </option>
                                <?php
                                // Fetch distinct department names
                                $fetch_department = mysqli_query($conn, "SELECT DISTINCT deptname FROM add_det");
                                while ($row = mysqli_fetch_array($fetch_department)) { ?>
                                    <option value="<?php echo htmlspecialchars($row['deptname']); ?>">
                                        <?php echo htmlspecialchars($row['deptname']); ?>
                                    </option>
                                <?php } ?>
                            </select>
                            <button type="submit" name="srh-btn" class="btn btn-primary">Search</button>
                        </form>

                       
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <li><a class="dropdown-item" href="#">Option 1</a></li>
                                <li><a class="dropdown-item" href="#">Option 2</a></li>
                                <li><a class="dropdown-item" href="#">Option 3</a></li>
                            </ul>
              

                        <a href="new-add-des.php" class="btn btn-success ms-2">ADD</a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <!-- <th>Name</th> -->
                                    <th>Department</th>
                                    <th>Designation</th>
                                    <!-- <th>Mobile</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($_REQUEST['srh-btn'])) {
                                    $deptname = $_POST['deptname'];
                                    $search_query = mysqli_query($conn, "SELECT * FROM add_det WHERE deptname='$deptname'");
                                    $sn = 1;
                                    while ($row = mysqli_fetch_array($search_query)) { ?>
                                        <tr>
                                            <td><?php echo $sn; ?></td>
                                            
                                            <td><?php echo $row['deptname']; ?></td>
                                            <td><?php echo $row['des']; ?></td>
                                            
                                        </tr>
                                    <?php $sn++;
                                    }
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
    <script language="JavaScript" type="text/javascript">
        function confirmDelete() {
            return confirm('Are you sure want to delete this Visitor?');
        }
    </script>
</div>
