<?php
session_start();
include ('connection.php');

// Check if the user is logged in
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if(empty($id)) {
    header("Location: index.php"); 
    exit();
}

// Fetch HR department details directly
$hr_query = mysqli_query($conn, "SELECT * FROM tbl_department WHERE deptname = 'HR'");
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <!-- <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">HR Department</a>
                </li> 
            </ol> -->

            <!-- HR Department Details -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    HR Department Details
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Department</th>
                                    <th>Designation</th>
                                    <th>Mobile</th>
                                </tr>  
                            </thead>
                            <tbody>
                                <?php
                                $sn = 1;
                                while($row = mysqli_fetch_array($hr_query)) { ?>
                                    <tr>
                                        <td><?php echo $sn; ?></td>
                                        <td><?php echo htmlspecialchars($row['fname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['deptname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['des']); ?></td>
                                        <td><?php echo htmlspecialchars($row['mobile']); ?></td>
                                    </tr>
                                <?php 
                                $sn++; 
                                }
                                ?>
                            </tbody>
                        </table>    
                    </div>
                </div>                   
            </div>
        </div>
    </div> 

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>
