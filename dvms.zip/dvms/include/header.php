<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <style>
        .logo {
            max-height: 40px;
            border-radius: 50%;
            margin-right: 10px; /* Space between logo and button */
        }

        .navbar {
            display: flex;
            align-items: center;
            justify-content: space-between; /* Space between left and right content */
            position: relative; /* Allows for absolute positioning */
        }

        .navbar-content {
            display: flex;
            align-items: center;
            justify-content: center; /* Center the title */
            flex-grow: 1; /* Allow the content to grow and take available space */
        }

        .title {
            margin: 0; /* Remove margin for better centering */
        }

        .logo-container {
            display: flex; /* Allow logo and button to be in the same row */
            align-items: center; /* Center vertically */
            position: absolute; /* Position logo and button absolutely */
            left: 20px; /* Adjust as needed */
        }
    </style>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Visitors Management System</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/custom_style.css?ver=1.1" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css' rel='stylesheet' />
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/themes/base/jquery-ui.css" rel="stylesheet" />
</head>

<body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
        <div class="container-fluid">
            <div class="logo-container">
                <img src="include/image.png" class="logo">
                <button class="btn btn-link btn-sm text-white" id="sidebarToggle" href="#">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="navbar-content">
                <h4 class="title">Visitors Management System</h4>
            </div>

            <form class="d-none d-md-inline-block form-inline ml-auto my-2 my-md-0">
                <span>Welcome!</span>
            </form>

            <!-- Navbar -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

</body>
</html>
