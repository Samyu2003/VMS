<?php
session_start();
include('connection.php');

$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
}
if (isset($_POST['sbt-vstr'])) {
    // Collect all the form data...
    $No_of_person = $_POST['No_of_person'];
    $name = $_POST['name'];
    $cno = $_POST['cno'];
    $email = $_POST['email'];
    $organization = $_POST['organization'];
    $location = $_POST['location'];
    $No_of_vec = $_POST['No_of_vec'];
    $vectype = $_POST['vectype'];
    $vecregno = $_POST['vecregno'];
    $no_of_phones = $_POST['no_of_phones'];
    $mobtype = $_POST['mobtype'];
    $no_of_laptop = $_POST['no_of_laptop'];
    $lapsrno = $_POST['lapsrno'];
    $lapmodel = $_POST['lapmodel'];
    $no_of_charger = $_POST['no_of_charger'];
    $meet = $_POST['deptId'];
    $des = $_POST['des'];
    $visit = $_POST['visit'];
    $visitor_name = $_POST['visitor_name'];
    $in_time = $_POST['in_time'];

    // Capture image data
    $imageData = $_POST['image'];

    // Remove the data:image/png;base64 part
    $image = str_replace('data:image/png;base64,', '', $imageData);
    $image = str_replace(' ', '+', $image);

    // Generate a unique file name for the image
    $imageName = uniqid() . '.png';

    // Decode the base64 image
    $imageContent = base64_decode($image);

    // Save the image to a directory
    $imagePath = 'uploads/' . $imageName;
    file_put_contents($imagePath, $imageContent);

    // Insert the visitor data along with the image into the database
    for ($i = 0; $i < $No_of_person; $i++) {
        $insert_visitor = mysqli_query($conn, "
            INSERT INTO tbl_visitors 
            (No_of_person, name, cno, email, organization, location, No_of_vec, vectype, vecregno, 
            no_of_phones, mobtype, no_of_laptop, lapsrno, lapmodel, no_of_charger, meet, des, visit, 
            visitor_name, in_time, image)  
            VALUES ('$No_of_person', '{$name[$i]}', '{$cno[$i]}', '{$email[$i]}', '$organization', 
            '$location', '{$No_of_vec[$i]}', '{$vectype[$i]}', '{$vecregno[$i]}', '{$no_of_phones[$i]}', 
            '{$mobtype[$i]}', '{$no_of_laptop[$i]}', '{$lapsrno[$i]}', '{$lapmodel[$i]}', '$no_of_charger', 
            '$meet', '$des', '$visit', '$visitor_name', '$in_time', '$imagePath')
        ");

        if (!$insert_visitor) {
            echo "<script>alert('Error occurred while adding visitor: " . mysqli_error($conn) . "');</script>";
        }
    }

    echo "<script>alert('Visitor(s) added successfully.');</script>";
}

?>

<style>
                            /* Container to align the image field and capture button */
                            .image-upload-container {
                                display: flex;
                                align-items: center;
                            }

                            /* Style for the capture button */
                            #capture-btn {
                                margin-left: 10px;
                                padding: 10px;
                                background-color: #28a745;
                                color: white;
                                border: none;
                                cursor: pointer;
                            }

                            /* Style for the video stream and canvas */
                            #video {
                                display: none;
                                width: 100%;
                                max-width: 400px;
                            }

                            #canvas {
                                display: none;
                            }

                            /* Styling for the file upload button */
                            #upload-btn {
                                margin-top: 10px;
                            }
                        </style>

                            <div class="image-upload-container">
                                <input type="file" id="file-input" accept="image/*" name="image"
                                    style="height: 35px; width:280px">
                                <button id="capture-btn">Capture</button>
                            </div>

                            <!-- Video stream for camera preview -->
                            <video id="video" autoplay></video>

                            <!-- Hidden canvas where the captured image will be drawn -->
                            <canvas id="canvas"></canvas>

                            <!-- Hidden form to submit the captured image -->
                            <form id="image-upload-form" action="upload.php" method="POST"
                                enctype="multipart/form-data">
                                <input type="text" name="image" id="image-data">
                                <input type="submit" value="Upload Image" id="upload-btn"
                                    style="height: 35px;width: 120px;">
                            </form>

                            <script>
                                // Accessing HTML elements
                                const captureBtn = document.getElementById('capture-btn');
                                const video = document.getElementById('video');
                                const canvas = document.getElementById('canvas');
                                const imageData = document.getElementById('image-data');
                                const uploadForm = document.getElementById('image-upload-form');

                                // Get access to the user's camera when the capture button is clicked
                                captureBtn.addEventListener('click', function () {
                                    navigator.mediaDevices.getUserMedia({ video: true })
                                        .then(stream => {
                                            video.style.display = 'block'; // Display the video preview
                                            video.srcObject = stream; // Stream the video
                                            captureBtn.innerText = "Take Photo"; // Change button text
                                            captureBtn.addEventListener('click', takePhoto); // Bind photo taking to button
                                        })
                                        .catch(err => {
                                            console.error('Error accessing the camera: ', err);
                                        });
                                });

                                // Function to take a photo
                                function takePhoto() {
                                    console.log('ff');
                                    
                                    // Draw the video frame into the canvas
                                    const context = canvas.getContext('2d');
                                    canvas.width = video.videoWidth;
                                    canvas.height = video.videoHeight;
                                    context.drawImage(video, 0, 0, canvas.width, canvas.height);
                                    console.log(context);
                                    
                                    // Stop the video stream
                                    const stream = video.srcObject;
                                    const tracks = stream.getTracks();
                                    tracks.forEach(track => track.stop());
                                    console.log('ss');
                                    
                                    video.style.display = 'none'; // Hide video preview

                                    // Convert the canvas image to base64 and set it to the hidden field
                                    const dataURL = canvas.toDataURL('image/png');
                                    imageData.value = dataURL;

                                    // Automatically submit the form (if needed) or show the upload button
                                    document.getElementById('upload-btn').style.display = 'block';
                                }
                            </script>
