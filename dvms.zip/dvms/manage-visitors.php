<?php
session_start();
include('connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if(empty($id)) {
    header("Location: index.php"); 
}

// Fetch the message from query string
$message = isset($_GET['msg']) ? $_GET['msg'] : '';
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">View Visitors</a>
                </li> 
            </ol>

            <!-- Display message -->
            <?php if ($message): ?>
                <div class="alert alert-info">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <!-- Search Form -->
            <form method="post">
                <div class="form-group row" style="padding: 20px;">
                    <label class="col-lg-0 col-form-label-report" for="from">From</label>
                    <div class="col-lg-3">
                        <input type="text" class="form-control" id="from_date" name="from_date" placeholder="Select Date" required>
                    </div>
                    <label class="col-lg-0 col-form-label" for="from">To</label>
                    <div class="col-lg-3">
                        <input type="text" class="form-control" id="to_date" name="to_date" placeholder="Select Date" required>
                    </div>
                    <div class="col-lg-3">
                        <button type="submit" name="srh-btn" class="btn btn-primary search-button">Search</button>
                    </div>
                    <br><br>
                </div>
            </form>

            <!-- Visitors Table -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    View Visitors
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Organization</th>
                                    <th>Mobile</th>
                                    <th>Purpose to meet</th>
                                    <th>Person to meet</th>
                                    <th>In Time</th>
                                    <th>Status</th>
                                    <th>Status Update</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if(isset($_REQUEST['srh-btn'])) {
                                    $from_date = $_POST['from_date'];
                                    $to_date = $_POST['to_date'];
                                    $from_date = date('Y-m-d', strtotime($from_date));
                                    $to_date = date('Y-m-d', strtotime($to_date));

                                    $search_query = mysqli_query($conn, "SELECT * FROM tbl_visitors WHERE DATE(in_time) >= '$from_date' AND DATE(in_time) <= '$to_date'");
                                    $sn = 1;
                                    while($row = mysqli_fetch_array($search_query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $sn; ?></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['organization']); ?></td>
                                            <td><?php echo htmlspecialchars($row['cno']); ?></td>
                                            <td><?php echo htmlspecialchars($row['meet']); ?></td>
                                            <td><?php echo htmlspecialchars($row['visit']); ?></td>
                                            <td><?php echo htmlspecialchars($row['in_time']); ?></td>
                                            <td><?php echo htmlspecialchars($row['status'] ? $row['status'] : 'Pending'); ?></td>
                                            <td>
                                                <a href="approve.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">View</a>
                                            </td>
                                        </tr>
                                        <?php
                                        $sn++;
                                    }
                                } else {
                                    $select_query = mysqli_query($conn, "SELECT * FROM tbl_visitors");
                                    $sn = 1;
                                    while($row = mysqli_fetch_array($select_query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $sn; ?></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['organization']); ?></td>
                                            <td><?php echo htmlspecialchars($row['cno']); ?></td>
                                            <td><?php echo htmlspecialchars($row['meet']); ?></td>
                                            <td><?php echo htmlspecialchars($row['visit']); ?></td>
                                            <td><?php echo htmlspecialchars($row['in_time']); ?></td>
                                            <td><?php echo htmlspecialchars($row['status'] ? $row['status'] : 'Pending'); ?></td>
                                            <td>
                                                <a href="approve.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">View</a>
                                            </td>
                                        </tr>
                                        <?php 
                                        $sn++;
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>                   
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>
