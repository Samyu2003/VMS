<?php
session_start();
include('connection.php');

$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
}

if (isset($_POST['sbt-vstr'])) {
    // Collect all the form data...
    $No_of_person = $_POST['No_of_person'];
    $name = $_POST['name'];
    $cno = $_POST['cno'];
    $email = $_POST['email'];
    $organization = $_POST['organization'];
    $location = $_POST['location'];
    $No_of_vec = $_POST['No_of_vec'];
    $vectype = $_POST['vectype'];
    $vecregno = $_POST['vecregno'];
    $no_of_phones = $_POST['no_of_phones'];
    $mobtype = $_POST['mobtype'];
    $no_of_laptop = $_POST['no_of_laptop'];
    $lapsrno = $_POST['lapsrno'];
    $lapmodel = $_POST['lapmodel'];
    $no_of_charger = $_POST['no_of_charger'];
    $meet = $_POST['deptId'];
    // $des = $_POST['des'];
    $visit = $_POST['visit'];
    $visitor_name = $_POST['visitor_name'];
    $in_time = $_POST['in_time'];

    for ($i = 0; $i < $No_of_person; $i++) {
        $insert_visitor = mysqli_query($conn, "
            INSERT INTO tbl_visitors 
            (No_of_person, name, cno, email, organization, location, No_of_vec, vectype, vecregno, 
            no_of_phones, mobtype, no_of_laptop, lapsrno, lapmodel, no_of_charger, meet,  visit, 
            visitor_name, in_time)  
            VALUES ('$No_of_person', '{$name[$i]}', '{$cno[$i]}', '{$email[$i]}', '$organization', 
            '$location', '{$No_of_vec[$i]}', '{$vectype[$i]}', '{$vecregno[$i]}', '{$no_of_phones[$i]}', 
            '{$mobtype[$i]}', '{$no_of_laptop[$i]}', '{$lapsrno[$i]}', '{$lapmodel[$i]}', '$no_of_charger', 
            '$meet',  '$visit', '$visitor_name', '$in_time')
        ");

        if (!$insert_visitor) {
            echo "<script>alert('Error occurred while adding visitor: " . mysqli_error($conn) . "');</script>";
        }
    }

    echo "<script>alert('Visitor(s) added successfully.');</script>";
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i>
                    Add Visitors
                </div>
                <div class="card-body">
                    <!-- Add back the form tag -->
                    <form method="post" class="form-valide">
                        <div class="row">
                            <div class="col-md-3 pt-3">
                                <label>No. Of Person</label>
                                <input type="number" class="form-control" style="height: 35px;" name="No_of_person"
                                    id="No_of_person" oninput="createPersonFields()" min="1" required>
                            </div>

                            <div id="persons"></div>

                            <script>
                                function createPersonFields() {
                                    var noOfPersons = parseInt(document.getElementById("No_of_person").value) || 0;
                                    var personsDiv = document.getElementById("persons");

                                    // Clear previous entries
                                    personsDiv.innerHTML = '';

                                    for (var i = 0; i < noOfPersons; i++) {
                                        var div = document.createElement('div');
                                        div.className = 'row mb-2';

                                        div.innerHTML = `
                                        <div class="col-md-4">
                                        
                                            <label>Full Name</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="name[]" required>
                                        </div>          
                                        <div class="col-md-4">
                                            <label>Contact Number</label>
                                            <input type="text" maxlength="10" class="form-control" style="height: 35px;width:280px" name="cno[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Email</label>
                                            <input type="email" class="form-control" style="height: 35px;width:280px" name="email[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Vehicle</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="No_of_vec[]" id="No_of_vec${i}" onchange="toggleVehicleFields(${i})">
                                                <option value=""> -- Select -- </option>
                                                <option value="yes">Yes</option>
                                                <option value="no">No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 vehicle-fields_${i}" style="display: none;">
                                            <label>Vehicle Type</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="vectype[]" required>
                                                <option value=""> -- Select -- </option>
                                                <option value="two-wheeler">Two Wheeler</option>
                                                <option value="four-wheeler">Four Wheeler</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 vehicle-fields_${i}" style="display: none;">
                                            <label>Registration No</label>
                                            <input type="text" class="form-control" maxlength="13" style="height: 35px;width:280px" name="vecregno[]"  placeholder="Format: TN 21 AN 8976" oninput="validateRegistrationNo(this, ${i})" title="Format: TN 21 AN 8976 (e.g., TN 21 AN 8976)">
                                            <small class="text-danger" style="display: none;" id="regNoError${i}">Invalid format! Use: TN 21 AN 8976</small>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Laptop</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="no_of_laptop[]" id="No_of_laptop${i}" onchange="toggleLaptopFields(${i})">
                                                <option value=""> -- Select -- </option>
                                                <option value="yes">Yes</option>
                                                <option value="no">No</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 laptop-fields_${i}" style="display: none;">
                                            <label>Serial Number</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="lapsrno[]" required>
                                        </div>
                                        <div class="col-md-4 laptop-fields_${i}" style="display: none;">
                                            <label>Laptop Model</label>
                                            <input type="text" class="form-control" style="height: 35px;width:280px" name="lapmodel[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>No of Phones</label>
                                            <input type="number" class="form-control" style="height: 35px;width:280px" name="no_of_phones[]" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Mobile Type</label>
                                            <select class="form-control" style="height: 35px;width:280px" name="mobtype[]" required>
                                                <option value=""> -- Select -- </option>
                                                <option value="With Camera">With Camera</option>
                                                <option value="Without Camera">Without Camera</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label>No.Of.Charger</label>
                                            <input type="number" class="form-control" style="height: 35px;width:280px" name="no_of_charger" required>
                                        </div>
                                    `;

                                        personsDiv.appendChild(div);
                                    }

                                    // Optionally reset readonly on the No_of_person input
                                    document.getElementById("No_of_person").removeAttribute("readonly");
                                }

                                function toggleVehicleFields(index) {
                                    var vehicleFields = document.querySelectorAll(`.vehicle-fields_${index}`);
                                    var vehicleSelect = document.getElementById(`No_of_vec${index}`);

                                    vehicleFields.forEach(field => field.style.display = vehicleSelect.value === 'yes' ? 'block' : 'none');
                                }

                                function toggleLaptopFields(index) {
                                    var laptopFields = document.querySelectorAll(`.laptop-fields_${index}`);
                                    var laptopSelect = document.getElementById(`No_of_laptop${index}`);

                                    laptopFields.forEach(field => field.style.display = laptopSelect.value === 'yes' ? 'block' : 'none');
                                }

                                function validateRegistrationNo(inputField, index) {
                                    const regNumber = inputField.value.trim();
                                    const regex = /^[A-Z]{2} \d{2} [A-Z]{2} \d{4}$/; // Adjust regex as necessary
                                    const errorMsg = document.getElementById(`regNoError${index}`);

                                    if (regex.test(regNumber)) {
                                        errorMsg.style.display = "none"; // Hide error message
                                    } else {
                                        errorMsg.style.display = "block"; // Show error message
                                    }
                                }
                            </script>

<div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Organization</label>
                                    <input type="text" name="organization" style="height: 35px;" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Location</label>
                                    <input type="text" style="height: 35px;" name="location" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Purpose of Visit</label>
                                    <input type="text" name="visit" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3 pt-3">
                                <label>Department</label>
                                <select class="form-control" style="height: 35px;" id="meet" name="deptId"
                                    required onchange="fetchDesignations(this.value)">
                                    <option value="">-- Select Department --</option>
                                    <?php
                                    $fetch_department = mysqli_query($conn, "SELECT * FROM add_det");
                                    while ($row = mysqli_fetch_array($fetch_department)) { ?>
                                        <option value="<?php echo htmlspecialchars($row['id']); ?>">
                                            <?php echo htmlspecialchars($row['deptname']); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="col-md-3 pt-3">
                                <label>Person to meet</label>
                                <select class="form-control" style="height: 35px;" name="visitor_name" required>
                                    <option value="">-- Select Person --</option>
                                </select>
                            </div>

                            <div class="col-md-3 pt-3">
                                <div class="form-group">
                                    <label>Visit Date and Time</label>
                                    <input type="datetime-local" style="height: 35px;" name="in_time"
                                        class="form-control" required min="<?php echo date('Y-m-d\TH:i'); ?>"
                                        title="Please select a date and time from today onward">
                                </div>
                            </div>

                            <div class="col-md-12 pt-3">
                                <button type="submit" name="sbt-vstr" class="btn btn-success">Submit</button>
                                <button type="button" class="btn btn-secondary" onclick="window.location.href='index.php'">Cancel</button>
                            </div>
                        </div>
                    </form> <!-- Close the form tag -->
                </div>
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <?php include('include/footer.php'); ?>
</div>


<script>
    function fetchDesignations(departmentId) {
        if (departmentId) {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_designations.php?dept_id=' + departmentId, true);
            xhr.onload = function () {
                if (this.status == 200) {
                    const designations = JSON.parse(this.responseText);
                    let options = '<option value="">-- Select Designation --</option>';
                    designations.forEach(function (des) {
                        options += `<option value="${des.id}">${des.des}</option>`;
                    });
                    document.getElementById('des').innerHTML = options;
                }
            };
            xhr.send();

            // Fetch persons to meet
            const xhrPersons = new XMLHttpRequest();
            xhrPersons.open('GET', 'fetch_persons.php?dept_id=' + departmentId, true);
            xhrPersons.onload = function () {
                if (this.status == 200) {
                    const persons = JSON.parse(this.responseText);
                    let options = '<option value="">-- Select Person --</option>';
                    persons.forEach(function (name) {
                        options += `<option value="${name}">${name}</option>`;
                    });
                    document.getElementsByName('visitor_name')[0].innerHTML = options;
                }
            };
            xhrPersons.send();
        } else {
            document.getElementsByName('visitor_name')[0].innerHTML = '<option value="">-- Select Person --</option>';
        }
    }
</script>

<!-- <script>
    function fetchDesignations(departmentId) {
        if (departmentId) {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_designations.php?dept_id=' + departmentId, true);
            xhr.onload = function () {
                if (this.status == 200) {
                    const designations = JSON.parse(this.responseText);
                    let options = '<option value="">-- Select Designation --</option>';
                    designations.forEach(function (des) {
                        options += `<option value="${des.id}">${des.des}</option>`;
                    });
                    document.getElementById('des').innerHTML = options;
                }
            };
            xhr.send();
        } else {
            document.getElementById('des').innerHTML = '<option value="">-- Select Designation --</option>';
        }
    }
</script> -->