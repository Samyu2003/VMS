<?php
include('connection.php');

if (isset($_GET['dept_id'])) {
    $dept_id = $_GET['dept_id'];
    $query = "SELECT * FROM des_table WHERE dept_id = '$dept_id'";
    $result = mysqli_query($conn, $query);
    $designations = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $designations[] = $row;
    }

    echo json_encode($designations);
}
?>