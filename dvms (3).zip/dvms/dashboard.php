<?php
session_start();
include 'connection.php';
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if(empty($id))
{
    header("Location: index.php"); 
}

 $total_visitors = mysqli_query($conn,"select count(*) from tbl_visitors");
 $total_visitors = mysqli_fetch_row($total_visitors);

 $today_visitors = mysqli_query($conn,"select COUNT(*) from tbl_visitors where DATE(in_time) = CURDATE();");
 $today_visitors = mysqli_fetch_row($today_visitors);

 $yesterday_visitors = mysqli_query($conn,"select count(*) from tbl_visitors where DATE(in_time)=CURDATE()-1");
 $yesterday_visitors = mysqli_fetch_row($yesterday_visitors);

 $week_visitors = mysqli_query($conn,"select count(*) from tbl_visitors where DATE(in_time)>= CURDATE()-7");
 $week_visitors = mysqli_fetch_row($week_visitors);

?>
<?php include('include/header.php'); ?>

  <div id="wrapper">

    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
         
        
          <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
        
        <body>

        <canvas id="myChart" style="width:100%;max-width:600px"></canvas>

        <script>
        var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
        var yValues = [55, 49, 44, 24, 15];
        var barColors = ["red", "green","blue","orange","brown"];

        new Chart("myChart", {
        type: "bar",
        data: {
            labels: xValues,
            datasets: [{
            backgroundColor: barColors,
            data: yValues
            }]
        },
        options: {
            legend: {display: false},
            title: {
            display: true,
            // text: "World Wine Production 2018"
            }
        }
        });
        </script>

        </div>
    </div>
   </div>
  </div>
</div>


  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php include('include/footer.php'); ?>

             





