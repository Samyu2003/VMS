<?php
include('connection.php');

if (isset($_GET['dept_id'])) {
    $dept_id = $_GET['dept_id'];
    $result = mysqli_query($conn, "SELECT fname FROM tbl_department WHERE deptname = '$dept_id'");
    
    $persons = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $persons[] = $row['fname'];
    }
    
    echo json_encode($persons);
}
?>
