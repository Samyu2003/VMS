<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="new-visitor.php" style="color: white;">
          <i class="fa fa-user"></i>
          <span>New Visitors</span>
        </a>  
        <li class="nav-item">
        <a class="nav-link" href="demo.php" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Transaction</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage-visitors.php" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Manage Visitors</span>
        </a>
        <li class="nav-item">
        <a class="nav-link" href="demo.php" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Audit</span>
        </a>
        <li class="nav-item">
        <a class="nav-link" href="demo.php" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Reports</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Manage Department</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-department.php">Employee Master</a>
          <a class="dropdown-item" href="view-department.php">Department Master</a>
          <a class="dropdown-item" href="hod-master.php">HOD Master</a>
      </div>
      </li>
     </ul>